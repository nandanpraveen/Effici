package com.effici.application

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.Button
import android.widget.CalendarView
import android.widget.TextView
import android.widget.Toast
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.date_screen)
        val dateChoosingCalendar = findViewById<CalendarView>(R.id.dateChoosingCalendar)
        lateinit var noteInputField: TextInputEditText
        var notesList = arrayListOf<Note>()
        lateinit var backButton: Button

        dateChoosingCalendar.setOnDateChangeListener { _, year, month, dayOfMonth ->
                val chosenDate = "$dayOfMonth-${month + 1}-$year"
                var noteAlreadyCreated = false
                var noteIndex = 0
                for (i in 0 until notesList.size) {
                    if (chosenDate == notesList[i].date) {
                        noteAlreadyCreated = true
                        noteIndex = i
                        break
                    }
                }

                if (noteAlreadyCreated) {
                    println("Note already created.")
                    setContentView(R.layout.note_template)
                    noteInputField = findViewById<TextInputEditText>(R.id.noteTakingField)
                    backButton = findViewById<Button>(R.id.changeButton)
                    backButton.setOnClickListener {
                        notesList[noteIndex].text = noteInputField.text
                        setContentView(R.layout.date_screen)
                        noteInputField.setText(notesList[noteIndex].text)
                    }
                } else {
                    notesList.add(Note(userinp = null, dateParam = chosenDate))
                    noteIndex = notesList.size - 1
                    setContentView(R.layout.note_template)
                    noteInputField = findViewById<TextInputEditText>(R.id.noteTakingField)
                    backButton = findViewById<Button>(R.id.changeButton)
                    println("A note for $chosenDate is added.")
                    backButton.setOnClickListener {
                        notesList[noteIndex].text = noteInputField.text
                        setContentView(R.layout.date_screen)
                    }
                }
            }
        }

    }


class Note(val userinp: Editable?, val dateParam: String)
{
    var text: Editable? = userinp
    var date = dateParam
}
